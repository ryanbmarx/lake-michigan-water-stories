Author: Cecilia Reyes
Organization: Chicago Tribune
Data: October 25, 2017

Not for commercial use

This zip file contains a number of documents containing materials related to [Water Drain](http://www.chicagotribune.com/water) project.  These include: 

    1. facid_name_place.csv 
    2. LMO2014_COMPILED.csv 
    3. LMO2016_COMPILED.csv 
    4. MHIB19013.csv (ACS-5 year 2015)
    5. SF1_P5.csv (Census 2010)
    6. SF3_P007.csv (Census 2000)
    7. water_bills_lm.csv (water bills compiled by the Chicago Tribune)

Document descriptions:

     facid_name_place.csv:
      Crosswalk file listing a town's NAME (Census' GEO.display-label), FAC_ID (Facility ID used in LMO), FAC_NAME (Town/place names adhering to Trib style) and PLACEID (Census' GEO.id2)

     LMO20<year>_COMPILED.csv:
      Transcribed LMO-2 reports for 2014 and 2016. IDNR changed the forms between those two years. The Tribune did not transcribe all of the information on the forms, but focused only on WATER_SUPPLIED, APPARENT_LOSSES (MGY and MGD), COST of both types of losses, % ALL_NONREVENUE_WATER

      For more information on the 2016 LMO variables, [see](http://www.awwa.org/portals/0/files/resources/water%20knowledge/water%20loss%20control/iwa-awwa-method-awwa-updated.pdf).

     <MHIB19013>||<SF1_P5>||<SF3_P007>.csv:
       Census files used to merge in demographic information to each town. The MHI information comes from the 5-year 2015 ACS. The P5 and P007 tables for the 2000 and 2010 census, respectively, break down the race and ethnicity of each town's population.
       Note: Leyden Township had to be added separately to the raw files from the census website.

     water_bills_lm.csv:
       The Tribune's collected data from all 163 municipalities that receive Lake Michigan water and have publicly managed water systems. Columns included: FAC_ID,FAC_NAME,gal5K_17,gal5K_13. For more information on the calculated bill amounts at 5K gallons consumption, [see](http://graphics.chicagotribune.com/news/lake-michigan-drinking-water/methods.html) or email: creyes@chicagotribune.com